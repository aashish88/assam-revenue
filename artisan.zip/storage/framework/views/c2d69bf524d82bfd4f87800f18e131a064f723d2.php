<?php $__env->startSection('content'); ?>
<div class="content-wrapper">

  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Table User List</h4>
        <p class="card-description">
          Table <code>User List</code>
        </p>
        <div class="table-responsive pt-3">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Staff</th>
                <th>Id Number</th>
                <th>Role</th>
                <th>Email</th>
                <th>Contact No.</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>

                <?php $i = 0; ?>
                <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    <?php $i++; ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($res->name); ?></td>
                    <td>
                        <?php if($res->user_type == 1): ?>
                        Admin
                        <?php elseif($res->user_type == 2): ?>
                        Officer Center
                        <?php elseif($res->user_type == 3): ?>
                        Vendor
                        <?php elseif($res->user_type == 4): ?>
                        Engineer
                        <?php elseif($res->user_type == 5): ?>
                        Officer Site
                        <?php endif; ?>
                    </td>
                    <td>$ 77.99</td>
                    <td>
                        <?php if($res->user_type == 1): ?>
                        Admin
                        <?php elseif($res->user_type == 2): ?>
                        Officer Center
                        <?php elseif($res->user_type == 3): ?>
                        Vendor
                        <?php elseif($res->user_type == 4): ?>
                        Engineer
                        <?php elseif($res->user_type == 5): ?>
                        Officer Site
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($res->email); ?></td>
                    <td><?php echo e($res->contect_no); ?></td>
                    <td>Active</td>
                    <td><i class="mdi mdi-rename-box"></i> | <i class="mdi mdi-delete"></i>

                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  

    <!-- Trigger the modal with a button -->
<?php if($title == "model"): ?>
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

<?php endif; ?>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4>Modal Header</h4>
        
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
     <?php if($title == "testing"): ?>
     <form action="<?php echo e(route('create_modal')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <div class="col-md-8">
                <div class="form-group row">
                <label class="col-sm-3 col-form-label">Status</label>
                <div class="col-sm-9">
                    <select class="form-control" name="status" id="status">
                    <option value="">---Select Status---</option>
                    <option value="1" <?php //if(old('status') == 1){ echo 'selected'; } ?>>Active</option>
                    <option value="2" <?php// if(old('status') == 2){ echo 'selected'; } ?>>Deactive</option>

                    </select>
                </div>
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" name="submit" value="submit" class="btn btn-primary mr-2">Submit</button>

            </div>
       </form>
     <?php endif; ?>
    </div>

  </div>
</div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/user/list.blade.php ENDPATH**/ ?>