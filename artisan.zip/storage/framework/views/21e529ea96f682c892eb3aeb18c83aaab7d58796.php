<?php $__env->startSection('content'); ?>
<style>
    .item-list-batch {
        margin: 10px 00px 00px 12px;
    }
    .card-title{
        /*background: rgb(119, 185, 216);*/
    align-content: center;
    margin: 15px 1px 1px 143px;
    }

    .ajaxitemheader{
        text-align: justify;
        font-size: 18px;
    }
</style>
<div class="content-wrapper">
    <?php if(session('success')): ?>
        <div id="hideDivAlert">


            <div class="alert alert-success mt-4 d-flex align-items-center hideDivAlert">
                
                <p>
                    <?php echo e(session('success')); ?>

                </p>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-12 grid-margin">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Assign Site to Vendor</h4>
            <form class="form-sample" action="<?php echo e(route('post-vendor-site')); ?>" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">Vendor Name</label>
                    <div class="col-sm-9">
                        <select class="form-control" value="<?php echo e(old('vendor_name')); ?>" name="vendor_name">
                            <option value="">---Select Vendor---</option>
                            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($res->id); ?>" <?php if(old('vendor_name') == 1){ echo 'selected'; } ?>><?php echo e($res->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                  </div>
                </div>
                    <div class="col-md-6">

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Site ID <i style="color: red; font-size: 20px">*</i></label>
                            <div class="col-sm-9">
                                <select class="form-control js-example-basic-multiple" value="<?php echo e(old('site_id')); ?>" name="site_id[]" multiple="multiple">
                                    <option value="">---Select Site---</option>
                                    <?php $__currentLoopData = $siteData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($res->id); ?>" <?php if(old('site_id') == 1){ echo 'selected'; } ?>><?php echo e($res->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>
                    </div>
              </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Start Date</label>
                            <div class="col-sm-9">
                                <input type="date" class="form-control" name="date" value="<?php echo e(old('date')); ?>" placeholder="01/01/1900" />
                            </div>
                        </div>
                    </div>



                    <div class="col-md-6">
                        <div class="form-group row">
                        <label class="col-sm-3 col-form-label">End Date</label>
                            <div class="col-sm-9">
                                <input type="date" class="form-control" name="end_date" value="<?php echo e(old('end_date')); ?>" placeholder="01/01/1900" />
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Priority</label>
                            <div class="col-sm-9">
                                <select class="form-control" name="priority">
                                    <option value="">---Select Role---</option>
                                    <option value="2" <?php if(old('priority') == 1){ echo 'selected'; } ?>>1</option>
                                    <option value="3" <?php if(old('priority') == 2){ echo 'selected'; } ?>>2</option>
                                    <option value="1" <?php if(old('priority') == 3){ echo 'selected'; } ?>>3</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="submit" name="submit" value="vendor-site" class="btn btn-primary mr-2">Submit</button>
                <button class="btn btn-light">Cancel</button>
            </form>
          </div>
        </div>
      </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/mapping/vendor_site.blade.php ENDPATH**/ ?>