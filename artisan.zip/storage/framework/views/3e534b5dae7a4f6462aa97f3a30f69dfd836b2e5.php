
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <?php if(session('success')): ?>
        <div id="hideDivAlert">
            <div class="alert alert-success mt-4 d-flex align-items-center hideDivAlert">
                
                <p>
                    <?php echo e(session('success')); ?>

                </p>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-12 grid-margin">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Create New User</h4>
            <form class="form-sample" action="<?php echo e(route('create-user')); ?>" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <p class="card-description">
                Personal Info
              </p>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">User Name</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" name="user_name" value="<?php echo e(old('user_name')); ?>" placeholder="Enter User Name" />
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">Type of Staff</label>
                    <div class="col-sm-9">

                      <select class="form-control" value="<?php echo e(old('staff_type')); ?>" name="staff_type">
                        <option value="">---Select Staff---</option>
                        <option value="1" <?php if(old('staff_type') == 1){ echo 'selected'; } ?>>Admin</option>
                        <option value="2" <?php if(old('staff_type') == 3){ echo 'selected'; } ?>>Vendor</option>
                        <option value="3" <?php if(old('staff_type') == 2){ echo 'selected'; } ?>>Officer</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">Id Number</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" name="id_no" value="<?php echo e(old('id_no')); ?>" placeholder="Enter Id Number" />
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">Role</label>
                    <div class="col-sm-9">
                      <select class="form-control" name="role_type">
                        <option value="">---Select Role---</option>
                        <option value="2" <?php if(old('role_type') == 2){ echo 'selected'; } ?>>View</option>
                        <option value="3" <?php if(old('role_type') == 3){ echo 'selected'; } ?>>Update</option>
                        <option value="1" <?php if(old('role_type') == 1){ echo 'selected'; } ?>>Admin</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group row">
                    <label for="exampleInputEmail1" class="col-sm-3 col-form-label">Email address</label>
                    <div class="col-sm-9">
                      <input type="email" class="form-control" name="user_email" value="<?php echo e(old('user_email')); ?>" id="exampleInputEmail1" placeholder="Enter Email" />
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group row">
                    <label for="exampleInputEmail1" class="col-sm-3 col-form-label">Contact No</label>
                    <div class="col-sm-9">
                      <input type="number" class="form-control" name="user_no" value="<?php echo e(old('user_no')); ?>" id="exampleInputEmail1" placeholder="Enter Email" />
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">Status</label>
                    <div class="col-sm-9">
                      <select class="form-control" name="status" id="status">
                        <option value="">---Select Status---</option>
                        <option value="1" <?php if(old('status') == 1){ echo 'selected'; } ?>>Active</option>
                        <option value="2" <?php if(old('status') == 2){ echo 'selected'; } ?>>Deactive</option>
                        
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <button type="submit" name="submit" value="user" class="btn btn-primary mr-2">Submit</button>
            <button class="btn btn-light">Cancel</button>
            </form>
          </div>
        </div>
      </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/user/create.blade.php ENDPATH**/ ?>