<?php $__env->startSection('content'); ?>

<div>
    Site Repost List
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/engineer/site-reports-list.blade.php ENDPATH**/ ?>