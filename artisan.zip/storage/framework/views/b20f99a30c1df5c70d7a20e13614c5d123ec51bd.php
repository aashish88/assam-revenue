<?php $__env->startSection('content'); ?>

<div>
    Approve site completion work

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/engineer/site-approve-list.blade.php ENDPATH**/ ?>