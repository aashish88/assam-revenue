<?php $__env->startSection('content'); ?>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body,
button {
  font-family: "Inter", sans-serif;
  color: #343a40;
  line-height: 1;
}

.pagination,
.page-numbers {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
}

.pagination {
  margin-top: 5px;
}

.btn-nav,
.btn-page {
  border-radius: 50%;
  background-color: #fff;
  cursor: pointer;
}

.btn-nav {
  padding: 5px;
}

.btn-nav {
  width: 42px;
  height: 42px;
  border: 1.5px solid #087f5b;
  color: #087f5b;
}

.btn-nav:hover,
.btn-page:hover {
  background-color: #087f5b;
  color: #fff;
}

.btn-page {
  border: none;
  width: 36px;
  height: 36px;
  font-size: 16px;
}

.btn-selected {
  background-color: #087f5b;
  color: #fff;
}



.item-list-batch {
        margin: 10px 00px 00px 12px;
    }
    .card-title{
        /*background: rgb(119, 185, 216);*/
    align-content: center;
    margin: 15px 1px 1px 143px;
    }

    .ajaxitemheader{
        text-align: justify;
        font-size: 18px;
    }


</style>
    <div class="content-wrapper">

        <?php if(session('success')): ?>
            <div id="hideDivAlert">
                <div class="alert alert-success mt-4 d-flex align-items-center hideDivAlert">

                    <div class="row"><i class="menu-icon mdi mdi-login-variant"></i> &nbsp;
                        <p>
                            <?php echo e(session('success')); ?>

                        </p>
                    </div>
                </div>
            </div>
        <?php endif; ?>


        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="headertext">Mapping Vendor Site:</h4>
                        <div class="row">
                            <table class="table table-striped">
                                <tr>
                                    <th>#</th>
                                    <th>Vendor Name</th>
                                    <th>Site ID</th>
                                    <th>Site Name</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Priority</th>
                                </tr>
                            <?php $__currentLoopData = $sitedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($res->id); ?></td>
                                    <td><?php echo e($res->vendor_name); ?></td>
                                    <td><?php echo e($res->site_id); ?></td>
                                    <td><?php echo e($res->name); ?></td>
                                    <td><?php echo e($res->date); ?>

                                        
                                    </td>
                                        <td><?php echo e($res->end_date); ?> </td>
                                    <td><?php echo e($res->priority); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </table>






                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/mapping/vendor_site_list.blade.php ENDPATH**/ ?>