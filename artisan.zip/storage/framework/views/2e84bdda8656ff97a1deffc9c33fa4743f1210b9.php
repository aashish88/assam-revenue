<?php $__env->startSection('content'); ?>

<div>
    Site Complete Work
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/engineer/approve-site-complete-work.blade.php ENDPATH**/ ?>