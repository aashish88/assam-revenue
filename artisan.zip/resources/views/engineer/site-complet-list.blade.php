@extends('layouts.app')
@section('content')

<div>
    Site Complete List
</div>
@endsection
