@extends('layouts.app')
@section('content')

<div>
    Site Complete Work
</div>
@endsection
