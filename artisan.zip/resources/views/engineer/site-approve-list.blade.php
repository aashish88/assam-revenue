@extends('layouts.app')
@section('content')

<div>
    Approve site completion work

</div>
@endsection
