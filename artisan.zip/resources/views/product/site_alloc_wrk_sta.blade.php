@extends('layouts.app')
@section('content')

<h4>Sites Management</h4>

@endsection
