@extends('layouts.app')
@section('content')

<h4>Inventry Management Status</h4>

@endsection
