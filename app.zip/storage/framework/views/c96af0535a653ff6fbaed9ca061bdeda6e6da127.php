<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BOQ SERIAL NO</title>
    <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 5px;
  white-space: initial;

}

tr:nth-child(even) {
  background-color: #dddddd;
}



    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
            <th>#</th>
            <th>Item Name</th>
            <th>Item Discription</th>
            <th>Serial No</th>
            <th>Approve</th>
            <th>Disapprove</th>
            <th>Remark</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $i = 0;
            ?>
            <?php $__currentLoopData = $serialdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $i++
            ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($res->item_title); ?></td>
                    <td><?php echo e($res->item); ?></td>
                    <td><?php echo e($res->serial_no); ?></td>
                    <td>
                        <?php if($res->officer_status == 1): ?> Yes
                        <?php else: ?> NA <?php endif; ?>
                    </td>
                    <td><?php if($res->officer_status == 0): ?> Yes
                        <?php else: ?> NA <?php endif; ?> </td>
                    <td><?php echo e($res->officer_status); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/approve_pdf.blade.php ENDPATH**/ ?>