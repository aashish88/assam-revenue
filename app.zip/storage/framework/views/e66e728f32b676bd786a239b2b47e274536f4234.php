<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>PolluxUI Admin</title>
  <link rel="stylesheet" href="<?php echo e(asset('public/vendors/typicons/typicons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/vertical-layout-light/style.css')); ?>">
  <link rel="shortcut icon" href="<?php echo e(asset('public/images/favicon.png')); ?>" />

  <style>
    .brand-logo {
      /* background: #87CEEB; */
      background: white;
    }

    .brand-logo img {
      background: #87CEEB;
      margin: 17px 00 11px 87px;
      padding: 1px;
    }

    h5 {
      /*background: #75c9eb;*/
      text-align: center;
    }

    img {
        display: block;
        margin-left: auto;
        margin-right: auto;
    }
    .brand-logo img{
        padding: 00px;

    }

    .auth .brand-logo img {
        margin: 00 00 00 48px;
        width: 322px;
    }

    .imglogocenter {
        margin: 00 00 00 16px;
        width: 250px;
        height: 220px;
    }
  </style>
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            
            <div class="auth-form-light text-left">
              <div class="brand-logo">
                <div class="row">
                    <div class="col-sm-2">
                        <img class="imglogocenter" src="https://nenow.in/wp-content/uploads/2022/03/Assam-govt.jpg" alt="assam-logo">
                        
                    </div>
                    <div class="col-sm-10">
                        
                    </div>


                </div>

              </div>
              <h5>Assam Land Record </br> Project Management System</h5>
              
        <form class="pt-3" action="<?php echo e(route('login.post')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <input type="email" class="form-control form-control-lg" id="exampleInputEmail1" name="email" placeholder="Username">
            <?php if($errors->has('email')): ?>
              <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <input type="password" name="password" class="form-control form-control-lg" id="exampleInputPassword1" placeholder="Password">
            <?php if($errors->has('password')): ?>
              <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
          </div>
          <div class="mt-3">
            <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" type="submit" name="login" value="signin">SIGN IN </button>
            
          </div>
          
        </form>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- base:js -->
  <script src="<?php echo e(asset('public/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('public/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/template.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/settings.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/todolist.js')); ?>"></script>
  <!-- endinject -->
</body>

</html>
<?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/auth/login.blade.php ENDPATH**/ ?>