
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <?php if(session('success')): ?>
            <div id="hideDivAlert">
                <div class="alert alert-success mt-4 d-flex align-items-center hideDivAlert">
                    
                    <p>
                        <?php echo e(session('success')); ?>

                    </p>
                </div>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">BOQ EDIT:</h4>

                        <form class="form-sample" action="<?php echo e(route('boq.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($id); ?>">
                            <p class="card-description">
                                BOQ Edit
                            </p>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Item Title</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="item_title" value="<?php echo e($product_data->item_title); ?>" placeholder="Enter Site Name" />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Item</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="item" value="<?php echo e($product_data->item); ?>" />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Quantity</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="qty" value="<?php echo e($product_data->qty); ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">UOM</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="uom" value="<?php echo e($product_data->uom); ?>" />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">OEM</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="oem" value="<?php echo e($product_data->oem); ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Batch</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="batch_id" value="<?php echo e($product_data->batch_id); ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Site ID</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="site_id" value="<?php echo e($product_data->site_id); ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Store Manager</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="store_manager" value="<?php echo e($product_data->store_manager); ?>" />
                                        </div>
                                    </div>
                                </div>




                                <button type="submit" name="submit" value="boq_update" class="btn btn-primary mr-2">Submit</button>
                              <button class="btn btn-light">Cancel</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/product/boq/edit.blade.php ENDPATH**/ ?>