<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Batch No: 1</title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="table-responsive pt-3" style="margin: 0 auto;display: block;width: 500px;">
        <h2 style="text-align: center;">Assam Revenue Management System</h2>
        <h3>List of Batch Items For Approval by store Officer: Sunil | Dated: <?php echo e($datanew['date']); ?> </h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Item Name</th>
                    <th>Item Type</th>
                    <th>Item</th>
                    <th>Quantity</th>

                </tr>
            </thead>
            <tbody class="tbody">
                <?php
                    $i = 0;
                ?>
                <?php $__currentLoopData = $datanew['batchbydata']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $i++;
                ?>
                    <tr>
                        
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e(substr($res->item_title, 0, 10)); ?></td>
                        <td><?php echo e(substr($res->item_title, 0, 70)); ?></td>
                        <td><?php echo e($res->item); ?></td>
                        <td><?php echo e($res->qty); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/resume.blade.php ENDPATH**/ ?>