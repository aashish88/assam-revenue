<?php $__env->startSection('content'); ?>
<style>
    .item-list-batch {
        margin: 10px 00px 00px 12px;
    }
    .card-title{
    align-content: center;
    /* margin: 15px 1px 1px 143px; */
    }

    [type='checkbox'] {
        position: absolute;
        height: 25px;
        width: 25px;
        background-color: #eee;
    }
</style>
<div class="content-wrapper">
    <?php if(session('success')): ?>
        <div id="hideDivAlert">
            <div class="alert alert-success mt-4 d-flex align-items-center hideDivAlert">
                
                <p>
                    <?php echo e(session('success')); ?>

                </p>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-12 grid-margin">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Issue Material To Vendor</h4>
            <form class="form-sample" action="<?php echo e(route('post-issue-material-vendor')); ?>" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group row">
                    
                    <div class="col-sm-9">
                        <select id="vendorName" class="form-control" value="<?php echo e(old('vendor_name')); ?>" name="vendor_name">
                            <option value="">---Select Vendor---</option>
                            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option onclick="getfunction1()" value="<?php echo e($res->id); ?>" class="dropdown-item"><?php echo e($res->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group row">
                        <div class="col-sm-9">
                            <select id="vendorName2" class="form-control" value="<?php echo e(old('batch_name')); ?>" name="batch_name">
                                <option value="">---Select Batch---</option>
                                <?php $__currentLoopData = $batchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option onclick="getfunction2()" value="<?php echo e($res->id); ?>" class="dropdown-item"><?php echo e($res->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group row">
                        <div class="col-sm-9">
                            <select id="vendorName3" class="form-control" value="<?php echo e(old('item_name')); ?>" name="item_name">
                                <option value="">---Select Item---</option>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option onclick="getfunction3()" value="<?php echo e($res->id); ?>" class="dropdown-item"><?php echo e($res->item_title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
              </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                          <div class="table-responsive pt-3">
                            <table class="table table-striped project-orders-table">
                              <thead>
                                <tr>
                                  <th class="ml-5">ID</th>
                                  <th>Item name</th>
                                  <th>Item</th>
                                  <th>Quantity</th>
                                  <th>Batch Id</th>
                                  <th>Site Id</th>
                                  <th>Allocation</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php
                                    $i = 0;
                                ?>
                                <?php $__currentLoopData = $items_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $i++;
                                ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td class="ask_td"><?php echo e($res->item_title); ?></td>
                                        <td class="ask_td"><?php echo e($res->item); ?></td>
                                        <td><?php echo e($res->qty); ?></td>
                                        <td><?php echo e($res->batch_id); ?></td>
                                        <td><?php echo e($res->site_id); ?></td>
                                        <td class="ask_td1 checkcolumn1">
                                            <input type="checkbox" class="form-check-input" value="<?php echo e($res->id); ?>" name="allocateitemtovendor[]" style="width: 85px; margin: -14px 00 00 -45px">
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-9">
                    </div>
                    <div class="col-md-3">
                        <button type="submit" name="submit" value="vendor-site" class="btn btn-primary mr-2">Submit</button>
                    <button class="btn btn-light">Cancel</button>
                    </div>

                </div>

            </form>
          </div>
        </div>
      </div>
    </div>

    <script>
        $(function getfunction1(){
            var select = $('#vendorName');
            select.on('change', function(){
                var vendor_id = $(this).children(':selected').val();
                $.ajax({
                    type: "POST",
                    url: 'ajaxgetvendoridbymateriallist',
                    data: { "vendor_id": vendor_id , _token: '<?php echo e(csrf_token()); ?>' },
                    success: function (data) {

                    }
                });

            });
        });
    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assam-revenue\resources\views/mapping/issue_vendor.blade.php ENDPATH**/ ?>