@extends('layouts.app')
@section('content')
<div class="content-wrapper">


    @if (session('success'))
        <div id="hideDivAlert">
            <div class="alert alert-success mt-4 d-flex align-items-center hideDivAlert">
                <div class="row"><i class="menu-icon mdi mdi-login-variant"></i> &nbsp;
                    <p>
                        {{ session('success') }}
                    </p>
                </div>
            </div>
        </div>
    @endif

    @if (session('user_type') == 1)
    {{--Start Admin Dashboard--}}
    <div class="row">
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 style="margin: 18px 18px 18px 90px;">User Registered Details</h4>
                    <div class="row">
                        <table class="table table-striped">

                            <tr>
                                <th>Officer</th>
                                <th></th>
                                <th>Vendor</th>
                            </tr>
                            <tr>
                                <td>01</td>
                                <td></td>
                                <td>05</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 style="margin: 18px 18px 18px 90px;">Store Inventory Details</h4>
                    <div class="row">
                        <table class="table table-striped">

                            <tr>
                                <th>Total Quantity</th>

                                <th>Quantity Issue</th>

                                <th>Quantity in hand</th>
                            </tr>
                            <tr>
                                <td>10</td>
                                <td>2</td>
                                <td>8</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </div>

    {{--End Admin Dashboard--}}
    @elseif(session('user_type') == 2)
    {{--Start Officer Dashboard--}}
    <div class="row">
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">


                        <h4 style="text-align: center;">Site Data</h4>
                        <div class="row">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Total Site</th>
                                    <th>Completed</th>
                                    <th>In-progress</th>
                                    <th>Unallocated</th>
                                </tr>
                                <tr>
                                    <td>212</td>
                                    <td>35</td>
                                    <td>21</td>
                                    <td>10</td>
                                </tr>
                            </table>
                        </div>


                </div>
            </div>
        </div>

        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 style="margin: 18px 18px 18px 90px;">Store Inventory Details</h4>
                    <div class="row">
                        <table class="table table-striped">

                            <tr>
                                <th>Total Quantity</th>

                                <th>Quantity Issue</th>

                                <th>Quantity in hand</th>
                            </tr>
                            <tr>
                                <td>10</td>
                                <td>2</td>
                                <td>8</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 style="margin: 18px 18px 18px 90px;">Bill of Quantity Details</h4>
                    <div class="row">
                        <table class="table table-striped">

                            <tr>
                                <th>Approved</th>
                                <th>Pending</th>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>1</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{--End Officer Dashboard--}}
    @else
    {{--Start Vendor Dashboard--}}
    <div class="row">
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 style="text-align: center;">Site Vendor Dashboard</h4>
                    <div class="row">
                        <table class="table table-striped">
                            <tr>
                                <th>Allocated</th>
                                <th>Completed</th>
                                <th>Work In Progress</th>
                                <th>Open</th>
                            </tr>
                            <tr>
                                <td>15</td>
                                <td>4</td>
                                <td>8</td>
                                <td>3</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 style="text-align: center;">Site Vendor Dashboard</h4>
                    <div class="row">
                        <table class="table table-striped">
                            <tr>
                                <th>Allocated</th>
                                <th>Completed</th>
                                <th>Work In Progress</th>
                                <th>Open</th>
                            </tr>
                            <tr>
                                <td>15</td>
                                <td>4</td>
                                <td>8</td>
                                <td>3</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </div>

    {{-- <div class="row">
        <div class="col-xl-6 grid-margin stretch-card flex-column">
            <div class="row">
                <div class="card">

                    <div class="card-body">
                        <h4>Site Data Vendor or Officer</h4>
                        <div class="row">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Officer</th>
                                    <th></th>
                                    <th>Vendor</th>
                                </tr>
                                <tr>
                                    <td>01</td>
                                    <td></td>
                                    <td>05</td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    {{-- <div class="card-body d-flex flex-column justify-content-between">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <p class="mb-0 text-muted">Total Site</p>
                            <p class="mb-0 text-muted">212</p>
                        </div>
                        <h4>35</h4>
                        <canvas id="transactions-chart" class="mt-auto" height="65"></canvas>
                    </div> --}}
                    {{-- <div class="card-body d-flex flex-column justify-content-between">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <p class="mb-2 text-muted">Request</p>
                                <h6 class="mb-0">V-004</h6>
                            </div>
                            <div>
                                <p class="mb-2 text-muted">Orders</p>
                                <h6 class="mb-0">720</h6>
                            </div>
                            {{-- <div>
                                <p class="mb-2 text-muted">Revenue</p>
                                <h6 class="mb-0">5900</h6>
                            </div>
                        </div>
                        <canvas id="sales-chart-a" class="mt-auto" height="65"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div> --}}
    {{--End Vendor Dashboard--}}
    @endif
</div>


@endsection

